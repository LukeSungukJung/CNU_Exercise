#include<linux/init.h>
#include<linux/kernel.h>
#include<linux/module.h>

static int num =0;

int __init init_my_module(void){
	printk("Hello module! My classId is 0, StudentId is %d\n",num);
	return 0;
}

void __exit exit_my_module(void){
	printk("Bye!\n");
}

module_param(num,int,0);
module_init(init_my_module);
module_exit(exit_my_module);
MODULE_LICENSE("GPL");
